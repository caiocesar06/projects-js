import Company from '../../models/Company/Company'

const createCompany = (company: Company): void => {
  console.log('Company created', company)
}

export { createCompany }
