import React from 'react'
import { Outlet } from 'react-router-dom'

const CompaniesRoute: React.FC = () => {
  return <Outlet />
}

export default CompaniesRoute
